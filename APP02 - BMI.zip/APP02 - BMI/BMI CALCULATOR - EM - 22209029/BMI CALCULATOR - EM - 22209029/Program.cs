﻿using System;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Welcome to the BMI Calculator - Developed by Euan McGinness.");

        Console.Write("Hello, let's start by taking your name...");
        string fname = Console.ReadLine();

        Console.Write($"Hi {fname}, now let's calculate your BMI.");

        Console.Write("Would you like to enter your weight in kilograms or pounds? (Select using K & P): ");
        char weightType = Convert.ToChar(Console.ReadLine());

        double weight;
        if (weightType == 'K')
        {
            Console.Write("Enter your weight (KG's): ");
            weight = Convert.ToDouble(Console.ReadLine());
        }
        else if (weightType == 'P')
        {
            Console.Write("Enter your weight (Pounds): ");
            weight = Convert.ToDouble(Console.ReadLine()) * 0.453592;
        }
        else

{
            Console.WriteLine("I'm sorry. That's an incorrect input. Please restart the program...");
            return;
        }

        Console.Write("Enter your height (in meters): ");
        double height = Convert.ToDouble(Console.ReadLine());

        double BMI = weight / (height * height);

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"Your BMI is {BMI:F2}");
        Console.ForegroundColor = ConsoleColor.White;



        if (BMI < 18.5)
            Console.WriteLine($"Your BMI of {BMI:F2} is deemed as underweight, {fname}. An underweight BMI is anything less then 18.5");
        else if (BMI >= 18.5 && BMI <= 24.9)
            Console.WriteLine($"Your BMI of {BMI:F2} is a healthy weight and normal - Keep at your lifestyle, {fname}. A healthy BMI is between 18.5 - 24.9.");
        else if (BMI >= 25 && BMI <= 29.9)
            Console.WriteLine($"Your BMI of {BMI:F2} is classified as overwiehgt, {fname}. An overweight BMI is any result over 30.0.");
        else

            Console.WriteLine($"Your BMI f {BMI:F2} is considered obese, {fname}.");


        Console.WriteLine($"If you're an adult, BMI is a good way to get an idea of your health risks related to your weight. If your BMI is above 35, you're definitely putting your health at risk, no matter what other factors there are. Still, there are certain cases where BMI might not give an accurate reading on health risks if you're in the 25-35 BMI range. These cases include people from the BAME minority, Pregnant people or Bodybuilders...");
        Console.Write("For further information you can visit the NHS Website for more information on healthy choices and your lifestyle." +
            "visit www.nhs.uk");
    }
}
